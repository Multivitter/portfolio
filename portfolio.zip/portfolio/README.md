# 📊 Data Architecture Portfolio

> Проектирую и строю системы данных для e-commerce:
> от сырых API маркетплейсов до дашбордов, по которым принимают решения.

**Amazon · Walmart · Shopify · Weather → PostgreSQL → BI · AI-агенты**

🔗 **Live demo:** https://your-app.streamlit.app

---

## Как я приношу ценность бизнесу

Превращаю разрозненные данные в автономную экосистему:

- **Единое хранилище** — собираю данные со всех площадок (SP-API, Advertising API, Walmart, Shopify) в консолидированный DWH.
- **Полная автоматизация** — ~50 задач по расписанию, 24/7. Никаких ручных выгрузок и `python script.py`.
- **Отказоустойчивость** — auto-retry, мониторинг состояния пайплайнов и алерты в Telegram при любом сбое.
- **Драйв решений** — интерактивные дашборды, которые обновляются на свежих данных.
- **AI-автоматизация рутины** — ресток-агенты, PPC-алерты, чат-ассистенты на базе Claude/Gemini.

**Результат:** ноль пропущенных сбоев загрузки и высвобождение ~`[X]` часов аналитики в неделю за счёт автоматизации.

---

## Кейсы (в этом демо)

| Кейс | О чём |
|------|-------|
| 🛒 **Amazon Analytics** | ETL через SP-API, трекинг Buy Box, расчёт чистой маржи, живой дашборд |
| 🔄 **ETL Orchestrator** | Единый процесс держит аналитику 4 площадок 24/7, без даунтайма |
| 🔍 **Listing Analyzer** | Разбор листинга Amazon как продукт с оплатой за запуск ($2.99/run) |
| 🌦️ **External Data Enrichment** | Погодные данные для корреляции с динамикой спроса и логистикой |
| 🤖 **AI Agents** | Агенты на Claude/Gemini: ресток, PPC-алерты, обработка данных |

> ⚠️ Все данные в демо — синтетические. Реальные архитектуры и объёмы обсуждаю персонально под NDA.

---

## Стек

- **Ingestion & APIs:** Python · Amazon SP-API · Advertising API · Walmart API · Shopify API · Weather APIs
- **Storage & Processing:** PostgreSQL · SQL · кастомный ETL-оркестратор (Python, threading, расписание)
- **Presentation & AI:** Streamlit · Claude API · Gemini API · Telegram Bot API
- **Infra & DevOps:** Docker · Git · `[cloud — впиши свой: Heroku / GCP / AWS]`

---

## Запуск локально

```bash
git clone https://github.com/your-username/portfolio.git
cd portfolio
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Деплой (Streamlit Cloud)

1. Пушим репозиторий на GitHub.
2. На [share.streamlit.io](https://share.streamlit.io) → **New app** → выбираем репо.
3. Main file: `streamlit_app.py` → деплоим.
4. Вставляем ссылку в шапку профиля и в этот README.

---

## Структура проекта

```
streamlit_app.py            # точка входа / landing
pages/
  1_Amazon_Analytics.py     # дашборд Amazon (интерактив)
  2_ETL_Orchestrator.py     # визуализация ETL-пайплайна + схема
  3_Listing_Analyzer.py     # кейс продукта (pay-per-run)
  4_External_Data.py        # обогащение данных погодой
  5_AI_Agents.py            # демо AI-агентов
  6_Contact.py              # контакты
assets/
  orchestrator_architecture.svg
```

---

📬 **Контакты:** см. страницу Contact в приложении.
